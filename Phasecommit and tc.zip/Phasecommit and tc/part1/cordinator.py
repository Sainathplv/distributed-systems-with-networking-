import socket
import time

# Define the IP address and port number for each participant
participant1_addr = ('localhost', 5001)
participant2_addr = ('localhost', 6001)

# Define the message to be sent to participants
prepare_msg = 'PREPARE'

# Create a socket for each participant
participant1_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
participant2_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Set the timeout for the participant sockets to 5 seconds
participant1_socket.settimeout(5.0)
participant2_socket.settimeout(5.0)

# Connect to each participant
try:
    participant1_socket.connect(participant1_addr)
    print(f"connected  to participant1")
except socket.error as e:
    print(f"Coordinator: Could not connect to participant 1: {e}")
try:
    participant2_socket.connect(participant2_addr)
    print(f"connected to participant2")
except socket.error as e:
    print(f"Coordinator: Could not connect to participant 2: {e}")

time.sleep(12)  # Simulate coordinator failure

# Send the "prepare" message to each participant
for sock in [participant1_socket, participant2_socket]:
    try:
        sock.send(prepare_msg.encode())
    except socket.error as e:
        print(f"Coordinator: Could not send prepare message to participant: {e}")

# Wait for responses from participants
responses = []
for sock in [participant1_socket, participant2_socket]:
    try:
        response = sock.recv(1024).decode()
    except socket.timeout:
        response = 'NO'
        print("Coordinator: Timed out waiting for response from participant.")
    except socket.error as e:
        response = 'NO'
        print(f"Coordinator: Error while waiting for response from participant: {e}")
    responses.append(response)
print(f"Participant 1 response: {responses[0]}")
print(f"Participant 2 response: {responses[1]}")
# Check if both participants responded with "YES"
if 'NO' in responses:
    # If either participant responded with "NO", send the "abort" message to each participant
    abort_msg = 'ABORT'
    for sock in [participant1_socket, participant2_socket]:
        try:
            sock.send(abort_msg.encode())
        except socket.error as e:
            print(f"Coordinator: Error while sending abort message to participant: {e}")
    print("Coordinator: Transaction aborted.")
else:
    # If both participants responded with "YES", send the "commit" message to each participant
    commit_msg = 'COMMIT'
    for sock in [participant1_socket, participant2_socket]:
        try:
            sock.send(commit_msg.encode())
        except socket.error as e:
            print(f"Coordinator: Error while sending commit message to participant: {e}")
    print("Coordinator: Transaction committed successfully.")

# Close the sockets
participant1_socket.close()
participant2_socket.close()
