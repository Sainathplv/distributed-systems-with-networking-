import socket

# Define the IP address and port number for the coordinator
#coordinator_addr = ('localhost', 7000)

# Create a socket for the participant
participant_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the listening port
participant_socket.bind(('localhost', 6001))
participant_socket.listen()
print(f'Participant 2 listening on "localhost":"6001"')

while True:
    # Accept the connection from the coordinator
    coordinator_socket, coordinator_addr = participant_socket.accept()

    # Set the timeout for the coordinator_socket to 5 seconds
    coordinator_socket.settimeout(5.0)

    try:
        # Wait for the "prepare" message from the coordinator
        prepare_msg = coordinator_socket.recv(1024).decode()

        can_commit = True

        # Send a "YES" or "NO" response to the coordinator
        if can_commit:
            response_msg = 'YES'
        else:
            response_msg = 'NO'
        coordinator_socket.send(response_msg.encode())

    except socket.timeout:
        # If the coordinator_socket times out, send a "NO" response to the coordinator
        print("Participant2: Timed out waiting for prepare message from coordinator.")
        response_msg = 'NO'
        coordinator_socket.send(response_msg.encode())
    except socket.error as e:
        # If an error occurs, send a "NO" response to the coordinator
        print(f"Participant2: Error while waiting for prepare message from coordinator: {e}")
        response_msg = 'NO'
        coordinator_socket.send(response_msg.encode())

# Close the coordinator_socket
coordinator_socket.close()

# Close the participant_socket
participant_socket.close()
