* VENKATA SAINATH REDDY PALAVALA  - 1001949223
* KARTHIKEYA JANJANAM - 1002115909

* Language : Python
* IDE : Pycharm

### Steps to run
* There are for parts
* Part-1:
  * file structure : Project3\part1
  * execution : cd part1 ,"python3 cordinator.py"
  * first run both the participants "python3 p1.py" and "python3 p2.py"
  * you need to open this same code in three terminal to see the proper excecution by typing the above syntax.
  
* Part-2:
  * file structure:  Project3\part2
  * execution : cd part2,there are three codes to run
  * "python3 p1.py localhost 5001"
  * "python3 p2.py localhost 5002"
  * "python3 cor.py"

* Part-3:
  * file structure:  Project3\part3
  * execution : cd part3,there are three codes to run
  * "python3 p1.py"
  * "python3 p2.py"
  * "python3 cor.py" once you experience the crash it has to re_run the cor.py

* Part-4:
  * file structure:  Project3\part4
  * execution : cd part4,there are three codes to run
  * "python3 p1.py"
  * "python3 p2.py"
  * "python3 cor.py" once you experience the crash it has to re_run the cor.py
 