import socket
import json
import os
import time

def store_transaction_data(transaction_data):
    with open('transaction_data.json', 'w') as f:
        json.dump(transaction_data, f)

def load_transaction_data():
    with open('transaction_data.json', 'r') as f:
        return json.load(f)

def clear_transaction_data():
    if os.path.exists('transaction_data.json'):
        os.remove('transaction_data.json')

def main():
    participant_addresses = [('localhost', 5001), ('localhost', 5002)]

    try:
        transaction_data = load_transaction_data()
        print("Transaction data loaded, attempting to recover from crash...")
    except FileNotFoundError:
        transaction_data = {
            'status': 'pending',
            'sent_to': []
        }

    if transaction_data['status'] == 'pending':
        prepare_message = 'PREPARE'
        store_transaction_data(transaction_data)

        for address in participant_addresses:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect(address)
                s.sendall(prepare_message.encode())
                response = s.recv(1024).decode()

            if response != 'YES':
                print(f'Participant {address} refused to prepare.')
                exit(1)

        transaction_data['status'] = 'commit'
        store_transaction_data(transaction_data)
        print("Transaction status set to commit.")

    for address in participant_addresses:
        if str(address) not in transaction_data['sent_to']:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect(address)
                s.sendall('COMMIT'.encode())
                s.recv(1024)

            transaction_data['sent_to'].append(str(address))
            store_transaction_data(transaction_data)
            print(f"Sent commit message to {address}")

            if len(transaction_data['sent_to']) == 1:
                print('Simulating crash after sending commit message to the first participant...')
                # ifyou want to rerun automatically
                #time.sleep(5)  # Simulate a delay before recovering from the crash
                #print('Coordinator recovered from crash, continuing with the transaction...')
                exit(0)

    #clear_transaction_data()
    #print("Transaction completed and cleared.")
    print("Transcation completed")

if __name__ == '__main__':
    main()
