import socket

def main():
    host = 'localhost'
    port = 5002

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((host, port))
        s.listen(1)
        print(f'Participant running on {host}:{port}')
        while True:
            conn, addr = s.accept()
            with conn:
                print(f'Connected by {addr}')
                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    message = data.decode()
                    if message == 'PREPARE':
                        response = input("Enter response for prepare message (YES/NO): ").upper()
                    elif message == 'COMMIT':
                        response = 'OK'
                    else:
                        response = 'UNKNOWN'
                    conn.sendall(response.encode())

if __name__ == '__main__':
    main()
