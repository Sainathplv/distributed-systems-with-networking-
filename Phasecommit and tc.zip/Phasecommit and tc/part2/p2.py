import sys
import socket

# Get connection parameters from command line argument
if len(sys.argv) < 2:
    print('Usage: python participant2.py <host> <port>')
    sys.exit(1)
host = sys.argv[1]
port = int(sys.argv[2])

# Create socket and listen for connection
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((host, port))
s.listen(1)
print(f'Participant 2 listening on {host}:{port}')
conn, addr = s.accept()

# Receive transaction request from coordinator
data = conn.recv(1024)
if data == b'request':
    # Get response from cmd/line
    response = input('Enter response (yes/no): ')
    if response == 'yes':
        conn.sendall(b'yes')
    else:
        conn.sendall(b'no')

# Close connection and socket
conn.close()
s.close()
