import sys
import socket
import time

# List of participant nodes
participants = ['localhost:5001', 'localhost:5002']
print('Coordinator started')

# Set timeout for receiving responses from participants (in seconds)
response_timeout = 5

# Wait for participants to start and then connect to them
socks = []
for p in participants:
    host, port = p.split(':')
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    while True:
        try:
            s.connect((host, int(port)))
            break
        except ConnectionRefusedError:
            pass
    print(f'Connected to participant {p}')
    socks.append(s)

# Send transaction request to all participants
for s in socks:
    s.sendall(b'request')

# Wait for responses from participants
votes = []
start_time = time.time()
for i, s in enumerate(socks):
    s.settimeout(response_timeout)
    try:
        data = s.recv(1024)
    except socket.timeout:
        print(f'No response received from participant {i + 1}')
        votes.append(False)
        continue

    if data == b'yes':
        votes.append(True)
        print(f'Received "yes" from participant {i + 1}')
    else:
        votes.append(False)
        print(f'Received "no" from participant {i + 1}')

# Determine if transaction should be committed or aborted
if all(votes):
    print('Transaction committed.')
else:
    print('Transaction aborted due to node failure.')

# Close sockets
for s in socks:
    s.close()
