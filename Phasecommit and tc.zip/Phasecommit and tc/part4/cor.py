import socket
import time

coordinator_port = 5000
participant_ports = [5001, 5002]
timeout = 5
extended_timeout = 30

def send_message(sock, message):
    sock.sendall(message.encode())

def receive_message(sock, buffer_size=1024):
    return sock.recv(buffer_size).decode()

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as coordinator:
        coordinator.bind(('localhost', coordinator_port))
        coordinator.listen()

        participants = []
        for _ in range(len(participant_ports)):
            conn, _ = coordinator.accept()
            participants.append(conn)

        for participant in participants:
            send_message(participant, "prepare")

        commit = True
        for idx, participant in enumerate(participants):
            start_time = time.time()
            current_timeout = timeout
            while time.time() - start_time < current_timeout:
                try:
                    response = receive_message(participant)
                    print(f"Coordinator received '{response}' from Participant {participant_ports[idx]}")
                    if response == "no":
                        commit = False
                        break
                except socket.timeout:
                    if time.time() - start_time >= timeout and current_timeout == timeout:
                        print(f"Coordinator timed out waiting for Participant {participant_ports[idx]}, waiting for reconnection")
                        current_timeout = extended_timeout

                    if time.time() - start_time >= extended_timeout:
                        commit = False
                        print(f"Coordinator timed out waiting for Participant {participant_ports[idx]}")
                        break

        print("Coordinator: Transaction completed")
        decision = "commit" if commit else "abort"
        for participant in participants:
            send_message(participant, decision)

        # Expect reconnected participant
        reconnected_participant, _ = coordinator.accept()
        send_message(reconnected_participant, decision)
        print(f"Coordinator: Reconnected Participant {participant_ports[1]}")

        print(f"Coordinator: Transaction {decision}")
        for participant in participants:
            participant.close()

if __name__ == "__main__":
    main()
