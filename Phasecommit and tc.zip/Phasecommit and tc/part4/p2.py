import socket
import time

participant_port = 5002
failure = True
coordinator_port = 5000
timeout = 12

def send_message(sock, message):
    sock.sendall(message.encode())

def receive_message(sock, buffer_size=1024):
    return sock.recv(buffer_size).decode()

def store_transaction_info():
    with open(f'transaction_info_{participant_port}.txt', 'w') as file:
        file.write("yes")

def fetch_commit_info():
    with open(f'transaction_info_{participant_port}.txt', 'r') as file:
        return file.read()

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as participant:
        participant.connect(('localhost', coordinator_port))
        participant.settimeout(timeout)

        while True:
            message = receive_message(participant)
            if message == "prepare":
                store_transaction_info()
                send_message(participant, "yes")
                if failure:
                    print(f"Participant {participant_port}: Failure occurred")
                    participant.close()
                    time.sleep(10)
                    print(f"Participant {participant_port}: Reconnected")
                    stored_info = fetch_commit_info()
                    if stored_info == "yes":
                        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reconnected_participant:
                            reconnected_participant.connect(('localhost', coordinator_port))
                            reconnected_participant.settimeout(timeout)
                            #time.sleep(1)
                            send_message(reconnected_participant, "yes")
                            decision = receive_message(reconnected_participant)
                            print(f"Participant {participant_port}: {decision}")
                            break
                break

if __name__ == "__main__":
    main()
