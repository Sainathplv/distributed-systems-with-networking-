import socket

participant_port = 5001
coordinator_port = 5000
timeout = 60

def send_message(sock, message):
    sock.sendall(message.encode())

def receive_message(sock, buffer_size=1024):
    return sock.recv(buffer_size).decode()

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as participant:
        participant.connect(('localhost', coordinator_port))
        print(f"Participant {participant_port} connected to Coordinator {coordinator_port}")
        participant.settimeout(timeout)

        while True:
            message = receive_message(participant)
            if message == "prepare":
                response = "yes"
                print(f"Participant {participant_port} sending response: {response}")
                send_message(participant, response)
                decision = receive_message(participant)
                print(f"Participant {participant_port}: {decision}")
                break

if __name__ == "__main__":
    main()
