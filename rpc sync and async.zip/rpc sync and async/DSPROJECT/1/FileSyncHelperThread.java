import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class FileSyncHelperThread extends Thread {
  private File syncFolder;
  private long checkInterval;
  private long lastUpdateTime;

  public synchronized long getLastUpdateTime() {
    return lastUpdateTime;
}

public synchronized void setLastUpdateTime(long lastUpdateTime) {
    this.lastUpdateTime = lastUpdateTime;
}

  public FileSyncHelperThread(File syncFolder, long checkInterval) {
    this.syncFolder = syncFolder;
    this.checkInterval = checkInterval;
  }

  @Override
  public void run() {
    while (!isInterrupted()) {
      try {
        // Connect to the RMI registry
        Registry registry = LocateRegistry.getRegistry(1099);
        FileServer fileServer = (FileServer) registry.lookup("fileServer");

        // Get a list of files in the sync folder
        File[] files = syncFolder.listFiles();

        // For each file in the sync folder
        for (File file : files) {
          // Get the last modified time of the file
          long lastModified = file.lastModified();

          // Check if the file has been updated since the last check
        //   if (lastModified > fileServer.getLastUpdateTime(file.getName())) {
        //     // If the file has been updated, send the updated file to the server
        //     byte[] fileData = Files.readAllBytes(file.toPath());
        //     fileServer.uploadFile(file.getName(), fileData);

        //     // Update the last update time for the file
        //     fileServer.setLastUpdateTime(file.getName(), lastModified);
        //   }
        }

        // Sleep for the specified check interval
        sleep(checkInterval);
      } catch ( NotBoundException | InterruptedException | IOException e) {
        System.err.println("File sync helper thread exception: " + e.toString());
        e.printStackTrace();
      }
    }
  }
}
