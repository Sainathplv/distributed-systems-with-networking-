//package server;

import java.rmi.Remote;
import java.rmi.RemoteException;

//Remote Interface Class just like Hello.java in Demo
public interface FileServer extends Remote {
  

  void uploadFile(String fileName, byte[] fileData) throws RemoteException;
  byte[] downloadFile(String fileName) throws RemoteException;
  boolean deleteFile(String fileName) throws RemoteException;
  boolean renameFile(String oldFileName, String newFileName) throws RemoteException;
  
}
