//import server.FileServer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class FileClient {

  private FileClient(){}
  private static final String DOWNLOAD_FOLDER = "clientFolder/";
  private static final String CLIENT_UPLOAD_FOLDER = "clientFolder/";

  public static void main(String[] args) {

    System.out.println("\n------FileClient.java Executed---------\n");
    System.out.println("\n Welcome to Dropbox like Distributed System:\n");
    int input=0;
    Scanner sc = new Scanner(System.in);
    
    try {
      Registry registry = LocateRegistry.getRegistry(1099);
      FileServer fileServer = (FileServer) registry.lookup("fileServer");

      while(input!=-1){

        System.out.println("\n1.Upload File\n2.Download File\n3.Delete File\n4.Rename file\nEnter -1 to break:\n\nChoose your Option: ");
        
        input = sc.nextInt();
        // if(input==-1){
        //   //sc.close();
        //   break;
        // }
        if(input==1){
          Scanner scanner = new Scanner(System.in);
          System.out.println("Enter File Name: ");
          String inputFileName=scanner.nextLine();
          fileServer.uploadFile ( inputFileName, readFile(inputFileName));
          //scanner.close();
        }
        else if(input==2){
          Scanner scanner = new Scanner(System.in);
          System.out.println("Enter File Name to Download: ");
          String inputFileName=scanner.nextLine();
          byte[] fileData = fileServer.downloadFile ( inputFileName);
          writeFile(inputFileName, fileData);
          //scanner.close();
        }
        else if(input==3){
          System.out.println("Enter File Name to Delete: ");
          Scanner scanner = new Scanner(System.in);
          String inputFileName=scanner.nextLine();
          if(fileServer.deleteFile ( inputFileName)){
            System.out.println("Deleted Successfully");
          }
          else{
            System.out.println("Unable to Delete file");
          }
          //scanner.close();
        }
        else if(input==4){
          Scanner scanner = new Scanner(System.in);
          System.out.println("Enter Original File Name: ");
          String orgFileName= scanner.nextLine();
          System.out.println("Enter New File Name: ");
          String modFileName=scanner.nextLine();
          if(fileServer.renameFile ( orgFileName,modFileName)){
            System.out.println("Renamed Successfully");
          }
          else{
            System.out.println("Unable to Rename file");
          }
          //scanner.close();
        }
        
      }


      // Call the file server methods, for example:
      //byte[] fileData = fileServer.downloadFile("example.txt");
      //String fileName ="exampleFile1.txt";
      //byte[] fileData = fileServer.downloadFile("exampleFile1.txt");
      //File file = new File(DOWNLOAD_FOLDER+ fileName );
      //try (FileOutputStream fos = new FileOutputStream(file)) {
      //  fos.write(fileData);
      //} catch (IOException e) {
      //  throw new RemoteException("Failed to upload file", e);
      //}
      // ...
    } catch (RemoteException | NotBoundException e) {
      System.err.println("File client exception: " + e.toString());
      e.printStackTrace();
    }
  }
  
  public static byte[] readFile(String fileName) throws RemoteException {
    byte[] fileData;
    File file = new File(CLIENT_UPLOAD_FOLDER + fileName);
    try {
      fileData = Files.readAllBytes(file.toPath());
      return fileData;
    } catch (IOException e) {
      throw new RemoteException("Failed to Read file------->", e);
    }
  }

  public static void writeFile(String fileName,byte[] fileData) throws RemoteException {
    if(fileData.toString().equalsIgnoreCase("File not Found")){
      System.out.println("File Not Found\n");
      return;
    }
    File file = new File(DOWNLOAD_FOLDER + fileName);
    try (FileOutputStream fos = new FileOutputStream(file)) {
      fos.write(fileData);
    } catch (IOException e) {
      throw new RemoteException("Failed to Download file", e);
    }
  }
}
