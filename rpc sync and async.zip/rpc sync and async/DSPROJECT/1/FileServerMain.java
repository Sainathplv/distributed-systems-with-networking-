//package common;

//import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
//import java.nio.file.Files;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
//import java.rmi.server.UnicastRemoteObject;
//import java.util.Scanner;

//import server.FileServerImpl;

public class FileServerMain{
  public static void main(String[] args) {
    try {
      System.out.println("Hello ----->/n");
        //FileServerMain object = new FileServerMain();
        //FileServer fileServer = (FileServer) UnicastRemoteObject.exportObject(object, 0); 
        FileServer fileServer = (FileServer) new FileServerImpl();
        //File myObj = new File("clientFolder/exampleFile.txt");
        Path path = Paths.get(
            "clientFolder/exampleFile.txt");
        byte[] dataOutput = Files.readAllBytes(path);
      
        fileServer.uploadFile("exampleFile.txt", dataOutput);
        
      Registry registry = LocateRegistry.createRegistry(1099);
      registry.bind("fileServer",fileServer);
      //registry.rebind("fileServer", fileServer);
      System.out.println("File server ready");
    } catch (Exception e) {
      
      System.err.println("File server exception: " + e.toString());
      e.printStackTrace();
    }
  }
}
