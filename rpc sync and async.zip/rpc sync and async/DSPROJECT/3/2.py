import asyncio
from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.server import SimpleXMLRPCRequestHandler


# Restrict to a particular path.
class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC2',)
    


class AsyncOperations:
    def sort(self, array):
        return sorted(array)

    def add(self, i, j):
        return i + j


    def __init__(self):
        self.server = SimpleXMLRPCServer(("localhost", 5000),
                                         requestHandler=RequestHandler)
        self.server.register_function(self.sort, 'sort')
        self.server.register_function(self.add, 'add')
        self.server.register_introspection_functions()
        
        
async def run_server():
    await AsyncOperations().server.serve_forever()

async def main():
    await run_server()

if __name__ == '__main__':
    print(" server stareted running through port 5000.....")
    asyncio.run(main())
