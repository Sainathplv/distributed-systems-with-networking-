# PALAVALA VENKATA SAINATH REDDY    1001949223
import time
import os
import threading
# import requests
import socket
import json


directory = 'directory_a'

# socket
def server():
    s = socket.socket()
    port = 5000
    s.bind(('', port))
    s.listen()
    print("Server A running")
    while True:
        c, addr = s.accept()
        handle_conn(c)
    # s.close()


def handle_conn(c):
    c.send('Alive'.encode())
    alive = c.recv(1024).decode()
    if alive == 'files':
        sf = server_file_list()
        c.send(sf.encode())
    elif alive == 'download':
        file_name = c.recv(1024).decode()
        file = open('directory_a/'+file_name, 'rb')
        c.send(file.read())
        file.close()

def server_file_list():
    path = os.path.join(os.getcwd(), directory)
    dir = os.listdir(path)
    sorted(dir)
    result = {}
    for x in dir:
        obj = {}
        ls = os.path.join(path, x)
        object = os.stat(ls)
        obj['st_size'] = object.st_size
        obj['st_mtime'] = object.st_mtime
        obj['st_mode'] = oct(object.st_mode)[-3:]
        result[x] = obj
    js = json.dumps(result)
    return js


t = threading.Thread(target=server)
t.setDaemon(False)
t.start()


# Synchronization
def check_alive():
    s = socket.socket()
    port = 8000
    s.connect(('127.0.0.1', port))
    alive = s.recv(1024).decode()
    res = 500
    if alive != None:
        res = 200
    s.close()
    return res

def file_list():
    s = socket.socket()
    port = 8000
    s.connect(('127.0.0.1', port))
    s.recv(1024).decode()
    s.send('files'.encode())
    res = s.recv(1024).decode()
    s.close()
    js = json.loads(res)
    return js

def modify_test(x,y):
    path = os.path.join(os.getcwd(), directory)
    ls = os.path.join(path, x)
    object = os.stat(ls)
    if object.st_mtime < y['st_mtime']:
        return True
    else:
        return False


def classify_files(d):
    download_list = []
    modify_list = []
    path = os.path.join(os.getcwd(),'directory_a')
    dir = os.listdir(path)
    download_list = d
    for x in dir:
        if x in d:
            if modify_test(x, d[x]):
                modify_list.append({x:d[x]})
            del download_list[x]
    return download_list, modify_list


def download_file(filename, mtime):
    s = socket.socket()
    port = 8000
    s.connect(('127.0.0.1', port))
    file = open('directory_a/'+filename, 'wb')
    s.recv(1024).decode()
    s.send('download'.encode())
    s.send(filename.encode())

    data = s.recv(1024)
    file.write(data)
    file.close()
    os.utime(directory+'/'+filename, (mtime, mtime))
    s.close()



def job():
    startup = 0
    while True:
        try:
            if check_alive() == 200:
                down, mody = classify_files(file_list())
                print("Server B online")
                for x in down.keys():
                    download_file(x, down[x]['st_mtime'])
                for x in mody:
                    key=list(x.keys())[0]
                    download_file(key, x[key]['st_mtime'])
                time.sleep(4)
        except Exception as e:
            print("Server B offline", e)
            time.sleep(1)


t1 = threading.Thread(target=job)
t1.daemon = True
t1.start()