* VENKATA SAINATH REDDY PALAVALA  - 1001949223
* KARTHIKEYA JANJANAM - 1002115909

* Language : Python
* IDE : Pycharm

### Steps to run
* There are two parts
* Part-1:
  * file structure : pythonProject9\pase1
  * execution : cd pase1 ,"python3 unicast.py" (0-2) are process id's
  * the screenshot in the report tells you rest of the things like process id,choice, etc.
  * you need to open his same code in three terminal to see the proper by typing the above syntax.
  
* Part-2:
  * file structure:  pythonProject9\broadcast
  * execution : cd broadcast,there are three codes to run
  * "python3 p1.py"
  * "python3 p2.py"
  * "python3 p3.py"
 