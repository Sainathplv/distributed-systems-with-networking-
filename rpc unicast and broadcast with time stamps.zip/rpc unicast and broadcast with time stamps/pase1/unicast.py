import socket
import threading
import sys

NUMBER_OF_PROCESSES = 3
HOSTS = {
    0: ('localhost', 8000),
    1: ('localhost', 8001),
    2: ('localhost', 8002),
}


class VectorClock:
    """Vector clock is a clock that used to calculate timings of the
        process time between actions for every event
    """

    def __init__(self, host, process_id):
        self.host = host
        self.clock = [0] * NUMBER_OF_PROCESSES
        self.process_id = process_id

    def update(self, clock):
        for i in range(NUMBER_OF_PROCESSES):
            self.clock[i] = max(self.clock[i], int(clock[i]))

    def print_clock(self, before=True, sending=True):
        print(
            f"Clock {'Before' if before else 'After'} {'Sending ' if sending else 'Recieving'} {self.clock}"
        )

    def format_message(self, msg):
        return f"{msg}\n{self.clock}\n{self.process_id}".encode()

    def send(self):
        try:
            while True:
                print("1. Unicast\n2. Broadcast")
                choice = int(input("Enter choice (1 or 2): "))
                if choice == 1:
                    process_to_send = int(input("Enter process id to send message to (0-2) \n"))
                    msg = input("Enter message to send\n")
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    try:
                        sock.connect(HOSTS[process_to_send])
                        self.clock[self.process_id] += 1
                        self.print_clock(before=True, sending=True)
                        sock.send(self.format_message(msg))
                        self.clock[self.process_id] += 1
                        self.print_clock(before=False, sending=True)
                    except Exception as e:
                        print(e)
                    finally:
                        sock.close()
                elif choice == 2:
                    msg = input("Enter message to broadcast\n")
                    self.print_clock(before=True, sending=True)
                    self.clock[self.process_id] += 1
                    self.broadcast(self.format_message(msg))
                    self.print_clock(before=False, sending=True)
                else:
                    print("Invalid choice. Please try again.")
        finally:
            pass

    def broadcast(self, data: bytes):
        for key, value in HOSTS.items():
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            if key == self.process_id:
                continue
            sock.connect(value)
            sock.send(data)
            sock.close()

    def placeholder(self):
        return f"Test\n{self.clock}\n{self.process_id}".encode()

    def receive(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.bind(self.host)
            sock.listen(1)
            while True:
                con, address = sock.accept()
                messages = con.recv(1024).decode().split('\n')
                print(f"Message Recieved {messages[0]} from Process {messages[2]}")
                self.print_clock(before=True, sending=False)
                received_clock = messages[1].strip('[]').split(',')
                received_clock[self.process_id] = str(int(received_clock[self.process_id]) + 1)
                self.clock[self.process_id] = self.clock[self.process_id] + 1
                self.update(received_clock)
                self.print_clock(before=False, sending=False)
                if messages[2] != str(self.process_id):
                    # if the message is received from a different process, broadcast it
                    self.broadcast(self.format_message(messages[0]))
        except Exception as e:
            print(e)

if __name__ == '__main__':
    process_id = int(input("Enter process id (0-2): "))
    host = HOSTS[process_id]
    vc = VectorClock(host, process_id)

    # create threads for send and receive methods
    send_thread = threading.Thread(target=vc.send)
    receive_thread = threading.Thread(target=vc.receive)

    # start the threads
    send_thread.start()
    receive_thread.start()

    # wait for the threads to finish
    send_thread.join()
    receive_thread.join()

