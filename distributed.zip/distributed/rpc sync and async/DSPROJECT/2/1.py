import xmlrpc.client
import os
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import traceback, logging


client_path = "./client/"

rpccall = xmlrpc.client.ServerProxy("http://127.0.0.1:9000/", allow_none=True)



class Handler(FileSystemEventHandler):
  
   # @staticmethod   ref:()
   

        
   def _check_modification(filename):
       if filename in self.extra_files:
           self.trigger_reload(filename)
       basename = os.path.basename(filename)
       if basename.startswith(tuple(self.observable_paths)):
          if filename.endswitch((".pyc",".pyo",".py")):
             self.trigger_reload(filename)         
   def on_created(self, event):
        """Called when a file or directory is created.

        :param event:
            Event representing file/directory creation.
        :type event:
            :class:`DirCreatedEvent` or :class:`FileCreatedEvent`
        """
        rpccall.upload(os.path.basename(event.src_path),readfile(event.src_path))
        super().on_created(event)
    
   def on_deleted(self, event):
        """Called when a file or directory is deleted.

        :param event:
            Event representing file/directory deletion.
        :type event:
            :class:`DirDeletedEvent` or :class:`FileDeletedEvent`
        """
        rpccall.delete(os.path.basename(event.src_path))
        print("deleted")
        super().on_deleted(event)
   def on_modified(self, event):
        """Called when a file or directory is modified.

        :param event:
            Event representing file/directory modification.
        :type event:
            :class:`DirModifiedEvent` or :class:`FileModifiedEvent`
        """
        try:
           path = f"{client_path}/{os.path.basename(event.src_path)}"
           with open(path ,'r') as f:
              
              rpccall.upload(os.path.basename(event.src_path),xmlrpc.client.Binary(f.read()) )
              f.close()
        except:
            pass
        super().on_modified(event)
    
    

def readfile(SERVER_DATA_PATH):
    try:
        with open(client_path + "a.txt", 'rb') as handle:
            return handle.read()
    except:
        pass       


event_handler = Handler()
observer = Observer()
observer.schedule(event_handler, client_path, recursive=True)
observer.start()

print("client go head")
try:
    while True:
        time.sleep(4.0)
except KeyboardInterrupt:
    observer.stop()
     
observer.join()        
