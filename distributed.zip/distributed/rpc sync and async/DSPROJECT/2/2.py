from xmlrpc.server import SimpleXMLRPCServer
import logging
import traceback
import os
import threading

class upload(threading.Thread):
    def __init__(self, filename, text):
        threading.Thread.__init__(self)
        self.filename = filename
        self.text = text

    def run(self):
        path = f"{SERVER_DATA_PATH}/{self.filename}" 
        with open(path , 'wb') as f:
            buffer = f.write((self.text).data)


def uploadOperation(filename, text):
    upload(filename, text).run()






class delete(threading.Thread):
    def __init__(self, filename):
        threading.Thread.__init__(self)
        self.filename = filename

    def run(self):
        os.remove(SERVER_DATA_PATH  + self.filename)


def deleteOperation(filename):
    delete(filename).start()

SERVER_DATA_PATH = "./server/"

for file in os.listdir(SERVER_DATA_PATH ):
    try:
        if os.path.isfile(SERVER_DATA_PATH  + file):
            os.remove(SERVER_DATA_PATH + file)
    except:
        pass
s = SimpleXMLRPCServer(("localhost", 9000), logRequests=True, allow_none=True)
s.register_function(uploadOperation, "upload")
s.register_function(deleteOperation, "delete")
print("Starting the Server")
s.serve_forever()
