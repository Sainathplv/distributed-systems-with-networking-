//package server;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class FileServerImpl extends UnicastRemoteObject implements FileServer {
  private static final long serialVersionUID = 1L;
  private static final String UPLOAD_FOLDER = "serverFolder/";
  private static final String DOWNLOAD_FOLDER = "clientFolder/";

  public FileServerImpl() throws RemoteException {
    super();
  }

  @Override
  public void uploadFile(String fileName, byte[] fileData) throws RemoteException {
    File file = new File(UPLOAD_FOLDER + fileName);
    try (FileOutputStream fos = new FileOutputStream(file)) {
      fos.write(fileData);
    } catch (IOException e) {
      throw new RemoteException("Failed to upload file", e);
    }
  }

  @Override
  public byte[] downloadFile(String fileName) throws RemoteException {
    // File file = new File(UPLOAD_FOLDER + fileName);
    // Path pathToFile = Paths.get(fileName);
    // System.out.println("\n-->"+pathToFile.toAbsolutePath().toString()+ "\n --> "+file.toPath().toString());
    // try {
    //   return Files.readAllBytes(pathToFile.toAbsolutePath());
    // } catch (IOException e) {
    //   throw new RemoteException("Failed to download file------->", e);
    // }
//     File file;
//     try{
// file = new File(UPLOAD_FOLDER + fileName);
//     }
    // catch(Exception e){
    //   System.out.println("File Not Found");
    // }
    
    try {
      File file = new File(UPLOAD_FOLDER + fileName);
      return Files.readAllBytes(file.toPath());
    } catch (IOException e) {
      return "File not Found".getBytes();
      //throw new RemoteException("Failed to download file", e);
    }
  }

  @Override
  public boolean deleteFile(String fileName) throws RemoteException {
    File file = new File(UPLOAD_FOLDER + fileName);
    return file.delete();
  }

  @Override
  public boolean renameFile(String oldFileName, String newFileName) throws RemoteException {
    File oldFile = new File(UPLOAD_FOLDER + oldFileName);
    File newFile = new File(UPLOAD_FOLDER + newFileName);
    return oldFile.renameTo(newFile);
  }
}
