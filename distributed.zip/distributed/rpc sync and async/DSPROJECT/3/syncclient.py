import xmlrpc.client
import array as array


with xmlrpc.client.ServerProxy("http://localhost:6000/RPC2") as proxy:
     a = int(input("enter a value"))
     b = int(input("enter b value"))
         
     result = proxy.add(a,b)
     print("Result for synchronous add :", result)
     n = int(input("enter n value"))
     x=[]
     for i in range(n):
         y = int(input("enter the next value"))
         x.append(y)
     print(x) 
     
     result2 = proxy.sort(x)
     

     print("Result for syncsort :",result2)
