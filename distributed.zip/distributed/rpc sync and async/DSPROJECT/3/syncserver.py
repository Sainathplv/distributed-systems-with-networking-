from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.server import SimpleXMLRPCRequestHandler

# Restrict to a particular path.
class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC2',)

# The computation server class.
class SyncOperations:
    # Addition operation.
    def add(self, i, j):
        return i + j

    # Sort operation.
    def sort(self, array):
        return sorted(array)


    def __init__(self):
        self.current_id = 0

# Start the server.
with SimpleXMLRPCServer(('localhost', 6000), requestHandler=RequestHandler) as server:
    server.register_instance(SyncOperations())
    print("Listening on port 6000...")
    server.serve_forever()
