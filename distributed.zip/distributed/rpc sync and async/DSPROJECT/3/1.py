import xmlrpc.client
import asyncio

async def add(i, j):
    with xmlrpc.client.ServerProxy("http://localhost:5000/RPC2") as proxy:
        return proxy.add(i, j)

async def sort(array):
    with xmlrpc.client.ServerProxy("http://localhost:5000/RPC2") as proxy:
        return proxy.sort(array)

async def main():
    a = int(input("enter a value"))
    b = int(input("enter b value"))    
    result = await add(a, b)
    print("Async add is : ",result)
    n = int(input("enter n value"))
    x=[]
    for i in range(n):
        y = int(input("enter the next value"))
        x.append(y)
    print(x) 
    result2 = await sort(x)
    print("asyn sorted array is : ",result2)

if __name__ == '__main__':
    asyncio.run(main())
