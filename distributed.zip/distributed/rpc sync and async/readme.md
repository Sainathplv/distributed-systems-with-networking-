CSE 5306-001  2023
======================

AUTHORS:
----------
- VENKATA SAINATH REDDY PALAVALA  (1001949223) vrp9223@mavs.uta.edu

-  Karthikeya (1002115909) 


REQUIREMENT:
-------------
- JAVA
- Python 3.8 or 3.11

- Environment- virtual machine ubuntu,visual studio

CONTENT:
---------
- **PART 1**- Implementing multi-threaded server that support UPLOAD,DOWNLOAD,DELETE and RENAME file operations.
------ 
  **Implementation**- 
1. Open 1 directory for implementing part 1 
2. Run javac FileClient.java,fileservermain,fileserverimpl,fileservermain on a terminal using the following command

       java FileserverMain 
3. Simultanously open client.py on other terminal using the following command 

       java fileclient 
4. Enter the required number operation(1.Upload 2.Download 3. Rename 4.Delete)
5. Enter the file name to perform the particular operation.
--------

- **PART 2** Implementing the synchronised storage service
- ----------

**Implementation**

1. . Open 2 directory for implementing part 2 
2. Run 2.py(server) on a terminal using the following command

       python 2.py 
3. Simultanously open 1.py(client) on other terminal using the following command 

       python 1.py 
4. Using file explorer, access the path where the client and server folders are stored and perform required operations.

------------

- **PART 3** 
-------
**Implementaion**

SYNCHRONOUS
1. Open 3 directory for implementing part 3 
2. Run syncclient.py and syncserver.py on different  terminals using the following command

       python syncserver.py  
       python syncclient.py 
3. The functions would return addition numbers and sorted array.

ASYNCHRONOUS 
1. Open 3 directory for implementing part 3 
2. Run 1.py(client) and 2.py(server) on different  terminals using the following command

       python 1.py  
       python 2.py 
3. The functions would return addition numbers and sorted array.




