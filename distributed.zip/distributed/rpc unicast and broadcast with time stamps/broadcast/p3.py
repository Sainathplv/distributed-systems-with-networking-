import socket
import threading

BROADCAST_ADDR = "255.255.255.255"

HOST = '127.0.0.3'
BROADCAST_PORT = 5005
NUMBER_OF_PROCESSES = 3
BUFFER_SIZE = 1024

class Process3:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.sock.bind((HOST, BROADCAST_PORT))
        self.vector_clock = [0] * NUMBER_OF_PROCESSES

    def print_clock(self):
        print(f"Clock: {self.vector_clock}")

    def update_clock(self, received_clock):
        for i in range(NUMBER_OF_PROCESSES):
            self.vector_clock[i] = max(self.vector_clock[i], received_clock[i])

    def format_message(self, msg):
        return f"{msg}\n{self.vector_clock}\n3".encode()

    def broadcast(self, data):
        self.sock.sendto(data, (BROADCAST_ADDR, BROADCAST_PORT))

    def send_message(self):
        while True:
            msg = input("Enter message to broadcast: ")
            self.vector_clock[2] += 1
            self.print_clock()
            data = self.format_message(msg)
            self.broadcast(data)
            self.vector_clock[2] += 1
            self.print_clock()

    def receive_messages(self):
        print("\n p3:Listening for incoming messages on", BROADCAST_PORT)
        while True:
            data, addr = self.sock.recvfrom(BUFFER_SIZE)
            if addr[0] == HOST:
                continue
            messages = data.decode().split('\n')
            print(f"Received message '{messages[0]}' from process {messages[2]}")
            self.print_clock()
            received_clock = messages[1].strip('[]').split(',')
            received_clock = [int(x) for x in received_clock]
            received_clock[2] += 1
            self.vector_clock[2] += 1
            self.update_clock(received_clock)
            self.print_clock()
            #data = self.format_message(messages[0])
            #self.broadcast(data)

if __name__ == '__main__':
    process3 = Process3()

    send_thread = threading.Thread(target=process3.send_message)
    receive_thread = threading.Thread(target=process3.receive_messages)

    send_thread.start()
    receive_thread.start()

    #send_thread.join()
    receive_thread.join()
