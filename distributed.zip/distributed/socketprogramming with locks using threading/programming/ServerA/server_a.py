# imports
import socket, threading, os, time, json

port =  5000
portb = 8000

curr_file_state = []
locked = []
locked_fifo = []
count = 0


print_lock = threading.Lock()
directory= 'directory_a'



# create Sockets
def create_server():
    s = socket.socket()
    s.bind(('',port))
    s.listen()
    t1 = threading.Thread(target=request_B)
    t1.start()
    print('Server A started')
    while True:
        c, addr = s.accept()
        t2 = threading.Thread(target=talk_serverB, args=(c,))
        t2.start()
    s.close()



def upload_file(c, msg):
    c.send(msg)

def recieve_file(c):
    read = c.recv(1024)
    return read

def send(c, msg):
    c.send(msg.encode())


def recieve(c):
    read = c.recv(1024).decode()
    return read


def make_filelist():
    global curr_file_state
    tmp_files_state = []
    
    files_name = os.listdir(directory)
    files_name = sorted(files_name)
    for name in files_name:
        file_details = {}
        path = os.path.join(directory, name)
        size = os.stat(path).st_size
        modified_time = os.stat(path).st_mtime
        mode = os.stat(path).st_mode
        file_details['name'] = name
        file_details['size'] = size
        file_details['modified_time'] = modified_time
        file_details['mode'] = mode
        tmp_files_state.append(file_details)
    curr_file_state = tmp_files_state
    return tmp_files_state

def get_filelist():
    global locked
    global curr_file_state
    # scenario: when server starts
    curr_file_state = make_filelist()
    return curr_file_state

def send_file(file_name, c):
    path = os.path.join(directory, file_name)
    f = open(path, 'rb')
    file = f.read()
    upload_file(c, file)
    f.close()


# check if it is talking to serverB or client
# use url filtering to trigger different task

def talk_serverB(c):
    global locked
    whoisthis = recieve(c)
    print('whoisthis:',whoisthis)
    send(c, 'ok')
    if whoisthis == 'B':
        whatuwant = recieve(c)
        send(c, 'ok')
        if whatuwant == 'filelist':
            files = get_filelist()
            data = json.dumps(files)
            send(c, data)
        if whatuwant == 'file':
            file_download_name = recieve(c)
            send_file(file_download_name, c)
    elif whoisthis == 'C':
        files = get_filelist()
        data = json.dumps(files)
        send(c, data)
        recieve(c)
        send(c, json.dumps(locked))
    elif whoisthis == 'locked':
        whatuwant = recieve(c)
        locked.append(whatuwant)
    elif whoisthis == 'unlock':
        whatuwant = recieve(c)
        unlock(whatuwant)
    else:
        print("Unauthorised access",whoisthis)
    c.close()
    

# request for file list and required files
def make_file_request():
    s1 = socket.socket()
    s1.settimeout(3)
    s1.connect(('127.0.0.1', portb))
    send(s1, 'A')
    recieve(s1)
    send(s1, 'filelist')
    recieve(s1)
    read = recieve(s1)
    filelist = json.loads(read)
    s1.close()
    return filelist

# check modified file and new files
def check_extra_file():
    download_file_list = []
    list_files = list(make_file_request())
    our_files = get_filelist()
    
    for i in list_files:
        name = i['name']
        z = 0
        for j in our_files:
            if name == j['name']:
                z = 1
                if i['modified_time'] > j['modified_time']:
                    download_file_list.append(i)
                    break
        if z == 0:
            download_file_list.append(i)
    return download_file_list

# download files
def download_file(file_name):
    s1 = socket.socket()
    s1.settimeout(3)
    s1.connect(('127.0.0.1', portb))
    send(s1, 'A')
    recieve(s1)
    send(s1, 'file')
    recieve(s1)
    send(s1, file_name['name'])
    file = recieve_file(s1)
    f = open(directory+'/'+file_name['name'], 'wb')
    f.write(file)
    f.close()
    os.utime(directory+'/'+file_name['name'], (file_name['modified_time'], file_name['modified_time']))
    s1.close()

def download_file_locked(file_name):
    global locked_fifo
    s1 = socket.socket()
    s1.settimeout(3)
    s1.connect(('127.0.0.1', portb))
    send(s1, 'A')
    recieve(s1)
    send(s1, 'file')
    recieve(s1)
    send(s1, file_name['name'])
    file = recieve_file(s1)
    x = {}
    x['file'] = file
    x['meta'] = file_name
    locked_fifo.append(x)
    s1.close()


def unlock(filename):
    global locked_fifo
    global locked
    for x in locked_fifo:
        if x['meta']['name'] == filename:
            f = open(directory+'/'+filename, 'wb')
            f.write(x['file'])
            f.close()
            locked_fifo.remove(x)
    locked.remove(filename)



# final request for server
def request_B():
    global count
    while True:
        try:
            download_file_list = check_extra_file()
            print('Server B online')
            if len(download_file_list) == 0:
                print('No change')
            print('changes: ',len(download_file_list))
            print(download_file_list)
            for x in download_file_list:
                if x['name'] in locked:
                    print("2")
                    download_file_locked(x)
                else:
                    download_file(x)
            download_file_list = []
        except Exception as e:
            print('error: '+ str(e))
            print('Server B offline')
        time.sleep(4)
        count = 1

create_server()