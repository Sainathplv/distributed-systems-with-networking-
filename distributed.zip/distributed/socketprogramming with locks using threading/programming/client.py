import socket, threading, os, json, time
from datetime import datetime, timezone
import sys

port = 5000
data = None


def result():
    global data
    s = socket.socket()
    s.connect(('127.0.0.1', port))
    s.send('C'.encode())
    s.recv(1024)
    data = s.recv(1024)
    data = json.loads(data)
    # print(data)
    s.send('ok'.encode())
    lock = s.recv(1024)
    lock = json.loads(lock)
    print("index--name--size--modified--mode--locked")
    for i in range(len(data)):
        index = i
        size = data[i]['size']
        name = data[i]['name']
        times = datetime.fromtimestamp(data[i]['modified_time'], tz=timezone.utc)
        mode = data[i]['mode']
        locked = ''
        if name in lock:
            locked = 'locked'
        print(index,name,size,times,mode,locked, sep='--')
    

def lock(index):
    global data
    s = socket.socket()
    s.connect(('127.0.0.1', port))
    s.send('C'.encode())
    s.recv(1024)
    data = s.recv(1024)
    data = json.loads(data)
    s.send('ok'.encode())
    lock = s.recv(1024)
    lock = json.loads(lock)
    s = socket.socket()
    s.connect(('127.0.0.1', port))
    s.send('locked'.encode())
    s.recv(1024).decode()
    s.send(data[index]['name'].encode())


def unlock(index):
    global data
    s = socket.socket()
    s.connect(('127.0.0.1', port))
    s.send('C'.encode())
    s.recv(1024)
    data = s.recv(1024)
    data = json.loads(data)
    s.send('ok'.encode())
    lock = s.recv(1024)
    lock = json.loads(lock)
    s = socket.socket()
    s.connect(('127.0.0.1', port))
    s.send('unlock'.encode())
    s.recv(1024).decode()
    s.send(data[index]['name'].encode())

n = len(sys.argv)
if n == 1:
    result()
elif n == 3:
    if sys.argv[1] == '-lock':
        index = sys.argv[2]
        lock(int(index))
    if sys.argv[1] == '-unlock':
        index = sys.argv[2]
        unlock(int(index))