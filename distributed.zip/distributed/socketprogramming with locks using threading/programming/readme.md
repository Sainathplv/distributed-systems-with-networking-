* open 3 terminal
* 1st terminal || cd ServerA; python server_a.py
* 2nd terminal || cd ServerB; python server_b.py
* 3rd terminal || python client.py

* python client.py -lock index
* python client.py -unlock index