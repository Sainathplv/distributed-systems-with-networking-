# PALAVALA VENKATA SAINATH REDDY    1001949223
import socket
import json
from _datetime import datetime, timezone

def connect():
    s = socket.socket()
    port = 5000
    s.connect(('127.0.0.1', port))
    s.recv(1024).decode()
    s.send('files'.encode())
    res = s.recv(1024).decode()
    s.close()
    js = json.loads(res)
    dir_List = []

    for x in js.keys():
        dir_List.append(x)

    sorted(dir_List)

    print("name", "size", "modified time", "octal-file-permissions", sep="---")
    for x in dir_List:
        data1 = js[x]
        size = data1['st_size']
        mtime = data1['st_mtime']
        modified = datetime.fromtimestamp(mtime, tz=timezone.utc)
        filep = data1['st_mode']
        print(x, size, modified, filep, sep="---")

connect()